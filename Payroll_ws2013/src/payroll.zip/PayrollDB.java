import java.util.ArrayList;
import java.util.List;

public interface PayrollDB {
    //List<Employee> dbList = new ArrayList<>();
    public List<Employee> getEmployeeList();
}
